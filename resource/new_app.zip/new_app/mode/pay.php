﻿<div style="margin:0 10px">
    <h3>订单确认</h3>
    <?php
    $db = db('app_tc');
    $vo = $db->where(['id' => $_GET['tc_id']])->find();
    echo '<div style="background: #ffffff;padding: 10px;margin-top: 10px;border-top:3px solid #328cc9">';
    echo '<div class="row-col c_active div_shadow">';
    echo '<h4 style="margin: 10px 0">' . $vo['name'] . ' / ' . $vo["limit"] . '天</h4>';
    echo '<div class="sub">价格：' . $vo["jg"] . '元</div>';
    echo '<div class="sub">流量：' . $vo["rate"] . 'M</div>';
    echo '<div class="text-right" style="margin-top: 20px">';
    echo '<button id="" class="submit btn btn-info" data="alipay">支付宝支付</button> ';
    echo '<button id="" class="submit btn btn-info" data="wechat">微信支付</button> ';
    echo '<button id="" class="submit btn btn-info" data="qqpay">QQ支付</button>';
    echo '</div>';
    echo '</div>';
    echo '</div>';

    ?>
</div>
<script>
    $(function () {
        $(".submit").click(function () {
            $.post('?action=create_order', {
                'type': $(this).attr('data'),
                'tc_id': '<?php echo $_GET['tc_id']?>'
            }, function (result) {
                if (result.status === 0) {
                    window.location.href='?action=payment&order='+result.data.order;
                } else {
                    alert(result.msg)
                }
            }, "JSON")
        });
    });
</script>
