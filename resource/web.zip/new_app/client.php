<?php
/**
 * Author: DongGua
 * E-mail zhendongdong@foxmail.con
 * Date: 2018/6/18
 * Time: 18:21
 */
require('../system.php');
$action = $_GET['action'];
$agent = $_GET['agent'] ?: 0;
$username = $_GET['username'];
$password = $_GET['password'];



define("DID", $agent);

function create_order()
{
    return rand(1111, 999) . time();
}

function check_user()
{
    $username = $_GET['username'] ?: $_SESSION['username'];
    $password = $_GET['password'] ?: $_SESSION['password'];
    $res = db('openvpn')->where([_iuser_ => $username, _ipass_ => $password])->find();
    if (!$res) {
        die("登录信息错误");
    }
    $_SESSION['username'] = $res[_iuser_];
    $_SESSION['password'] = $res[_ipass_];
    return $res;
}

function getClientIP()
{
    global $ip;
    if (getenv("HTTP_CLIENT_IP"))
        $ip = getenv("HTTP_CLIENT_IP");
    else if (getenv("HTTP_X_FORWARDED_FOR"))
        $ip = getenv("HTTP_X_FORWARDED_FOR");
    else if (getenv("REMOTE_ADDR"))
        $ip = getenv("REMOTE_ADDR");
    else $ip = "Unknow";
    return $ip;
}

function create_fkj_order($order)
{
    require('../pay/FkPay.class.php');
    $isMobile = is_mobile_request();
    $m = new Map();
    $notify_url = $m->type("cfg_pay")->getValue("user_notify_url");
    $return_url = $m->type("cfg_pay")->getValue("user_return_url");
    $data = [
        "out_trade_no" => $order['order'],
        "total_amount" => $order['amount'],
        "return_url" => $return_url,
        "notify_url" => $notify_url,
        "spbill_create_ip" => getClientIP(),
        "subject" => "账户充值"
    ];
    //var_dump($data);
    $pay = new FkPay();
    if ($order['type'] == 'alipay') {
        $pay->method('alipay.trade.wap.pay');
    } elseif ($order['type'] == 'qqpay') {
        $pay->method('qq.pay.native');
    } else {
        $pay->method('wxpay.pay.h5');
    }
    $pay->setParams($data);
    $info = $pay->respone();
    if ($info['code'] == "10000") {
        if ($info['url'] != '') {
            header("location:" . $info['url']);
            exit();
        } elseif ($info['qr_code'] != '') {
//            echo $info['html'];
        } else {
            echo $info['html'];
        }
    } else {
        echo('订单创建失败');
    }
}

switch ($action) {
    case 'shop':
        $user_info = check_user();
        $title = '充值与续费';
        include("api_head.php");
        include("mode/ad.php");
        include("api_footer.php");
        break; 
	case 'line':
        $user_info = check_user();
        $title = '线路安装';
        include("api_head.php");
        include("mode/line.php");
        include("api_footer.php");
        break;
    case 'help':
//        $user_info = check_user();
        $title = '帮助中心';
        include("api_head.php");
        include("mode/help.php");
        include("api_footer.php");
        break;
    case 'connect':
//        $user_info = check_user();
        $title = '客服中心';
        include("api_head.php");
        include("mode/connect.php");
        include("api_footer.php");
        break;
    case 'notice_list':
        include('api_head.php');
        //include('list_gg.php');
        $u = $_GET['username'];
        $p = $_GET['password'];
        $db = db('app_gg');
        $list = $db->where(["daili" => DID])->order('id DESC')->select();
        echo '<div style="margin:10px 10px;">';
        echo '<div class="alert alert-warning">您可以在这看到最近30条消息通知</div>';
        echo '</div>';
        if ($list) {
            echo '<ul class="list-group">';
            foreach ($list as $v) {
                echo '<li class="list-group-item"><a href="">' . $v['name'] . '</a></li>
				';
            }
            echo '</ul>';
        } else {
            echo '消息已经删除或者不存在！';
        }

        include("api_footer.php");
        break;
    case 'notice':
        $db = db('app_gg');
        if ($notice = $db->where(["daili" => DID])->order('id DESC')->find()) {
            die(json_encode([
                'status' => 'success',
                'title' => $notice['name'],
                'content' => $notice['content']
            ]));
        };

        break;
    case 'userinfo':
        $u = check_user();
        $ud = new U($u[_iuser_], $u[_ipass_], true);
        if ($u) {
            $count = printmb($u[_maxll_]);
            $isuse = printmb($u[_irecv_] + $u[_isent_]);
            $sy = printmb($u[_maxll_] - ($u[_irecv_] + $u[_isent_]));
            $upload = printmb($u[_irecv_]);
            $download = printmb($u[_isent_]);
            $_sy = $ud->getDatadays();
            $s = $u[_maxll_] - ($u[_irecv_] + $u[_isent_]);
            $_all = $u[_maxll_] >= _MAX_LIMIT_ * 1024 * 1024 * 1024 ? "NO_LIMIT" : $s;
            die(json_encode([
                'status' => 'success',
                'bl' => $_all,
                'sy' => $_sy . "天"
            ]));
        } else {
            die(json_encode(['status' => 'error']));
        }
        break;
    case 'reg':
        $title = '新用户注册';
        include("api_head.php");
        $m =  new Map();
        $type = $m->type("cfg_app")->getValue("reg_type");
        if($type == "sms"){
            include("mode/dx_reg.php");
        }else{
            include("mode/app_reg.php");
        }
        include("api_footer.php");
        break;
    case 'pay':
        $user_info = check_user();
        $title = '充值与续费';
        include("api_head.php");
        include("mode/pay.php");
        include("api_footer.php");
        break;
    case 'payment':
        $order_no = $_GET['order'];
        $db = db('app_order_tc');
        $order = $db->where(['order' => $order_no, 'status' => 0])->find();
        if (!$order) {
            die('订单不存在');
        }
        create_fkj_order($order);
        break;
    case 'create_order':
        $user_info = check_user();
        $tc_id = $_POST['tc_id'];
        $type = $_POST['type'];
        $db = db('app_order_tc');
        $order = create_order();

        if ($tc_info = db('app_tc')->where(['id' => $tc_id])->find()) {
            if (!$db->where(['order' => $order])->find()) {
                $data['order'] = $order;
                $data['amount'] = $tc_info['jg'];
                $data['tc_id'] = $tc_id;
                $data['pay_amount'] = 0;
                $data['time'] = time();
                $data['type'] = $type;
                $data['uid'] = $user_info['id'];
                $data['status'] = 0;
                $data['status_time'] = time();
                if ($db->insert($data)) {
                    die(json_encode([
                        'status' => 0,
                        'msg' => 'success',
                        'data' => [
                            'order' => $order
                        ]
                    ]));
                }
                die(json_encode([
                    'status' => 1,
                    'msg' => '订单创建失败'
                ]));
            }
            die(json_encode([
                'status' => 1,
                'msg' => '订单已经存在'
            ]));
        }

        die(json_encode([
            'status' => 1,
            'msg' => '套餐不存在'
        ]));

        break;
}