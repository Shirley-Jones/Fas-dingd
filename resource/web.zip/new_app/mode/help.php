<?php
if (DID > 0) {
    $res = db("app_daili")->where(["id" => DID])->find();
    $data = $res;
} else {
    $m = new Map();
    $data = $m->type("cfg_app")->getAll();
}

?>
<div style="margin: 10px">
    <h3>帮助中心</h3>
    <div style="background: #ffffff;padding: 10px;margin-top: 10px;border-top:3px solid #328cc9">
        <?php
        echo html_decode($data["help"]);
        ?>

    </div>
</div>
