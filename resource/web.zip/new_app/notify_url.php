<?php
require("../system.php");
require("../pay/FkPay.class.php");
function outs($str)
{
    file_put_contents("log.txt", $str);
    die($str);
}

$no = $_POST["out_trade_no"]; // 订单号
$total_amount = $_POST["total_amount"]; // 支付金额
$sign = (new FkPay())->sign($_POST);
if (isset($_POST['sign']) && $sign == $_POST['sign']) {
    $db = db("app_order_tc");
    if ($order = $db->where(["order" => $no, "status" => 0])->find())
    {
        $db->where(["order" => $no])->update([
            'pay_amount' => $total_amount,
            'status' => 1,
            'status_time' => time()
        ]);
        $tc = db("app_tc")->where(["id" => $order['tc_id']])->find();
        if (!$tc) {
            die("此套餐已经失效了");
        }
        $uinfo = db(_openvpn_)->where(['id' => $order['uid']])->find();
        $duetime = time() + $tc['limit'] * 24 * 60 * 60;
        $addll = $tc['rate'] * 1024 * 1024;
        //已到期 清空全部流量
        $update[_maxll_] = $addll;
        $update[_endtime_] = $duetime;
        $update[_isent_] = "0";
        $update[_irecv_] = "0";
        $update[_i_] = "1";
        if (db(_openvpn_)->where(["id" => $uinfo["id"]])->update($update)) {
            die('success');
        } else {
            die('开通失败！');
        }
    } else {
        outs('order error');
    }
} else {
    outs('sign error' . $sign . $_POST['sign']);
}