#!/bin/bash
#FAS 自定义开机自启动控制器


case $Action in
	"start")
		sh /root/res/auto_run
		exit 0;
	;;
	"restart")
		sh /root/res/auto_run
		exit 0;
	;;
	"stop")
		exit 0;
	;;	
	"status")
		exit 0;
	;;
	"state")
		exit 0;
	;;
	
	*) 
		echo "此脚本为 Ubuntu FAS 开机自启专用,请勿手动执行!!!";
		exit 0;
    ;;
esac 
exit 0;
